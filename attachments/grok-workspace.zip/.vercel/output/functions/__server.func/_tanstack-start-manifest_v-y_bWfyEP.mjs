//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-y_bWfyEP.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/projects/$id",
			"/projects/"
		],
		preloads: ["/assets/index-Bo-kyNdh.js", "/assets/rolldown-runtime-hePW80VL.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-Bo-kyNdh.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		css: ["/assets/routes-PTugdkvS.css"],
		preloads: [
			"/assets/routes-DEakME5g.js",
			"/assets/ThemeToggle-asb1ISgL.js",
			"/assets/codexviber-mark-CuK-W9Kc.js",
			"/assets/CategoryTags-ksU60DPU.js"
		]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: void 0,
		preloads: [
			"/assets/admin-DGHDRU7b.js",
			"/assets/ThemeToggle-asb1ISgL.js",
			"/assets/codexviber-mark-CuK-W9Kc.js"
		]
	},
	"/projects/$id": {
		filePath: "/workspace/src/routes/projects/$id.tsx",
		children: void 0,
		preloads: ["/assets/_id-C712JNfv.js", "/assets/ThemeToggle-asb1ISgL.js"]
	},
	"/projects/": {
		filePath: "/workspace/src/routes/projects/index.tsx",
		children: void 0,
		preloads: [
			"/assets/projects-D3AHX6qF.js",
			"/assets/ThemeToggle-asb1ISgL.js",
			"/assets/codexviber-mark-CuK-W9Kc.js",
			"/assets/CategoryTags-ksU60DPU.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
